<!DOCTYPE html>
<html lang="fr">
<head><meta charset="UTF-8"><title>Application 2 - Gestion des stages</title><link rel="stylesheet" href="style.css"></head>
<body>
<h1>Application 2 — Gestion des stages</h1>
<nav><a href="index.php">Accueil</a> | <a href="entreprises.php">Entreprises</a> | <a href="encadreurs.php">Encadreurs</a> | <a href="stages.php">Stages</a> | <a href="evaluations.php">Évaluations</a></nav>
<p>Bienvenue. Cette application gère les <strong>entreprises</strong>, les <strong>encadreurs</strong>, les <strong>stages</strong> et les <strong>évaluations</strong>.</p>
<p>La liste des étudiants (nécessaire pour créer un stage) est récupérée en temps réel depuis l'application 1, via l'API.</p>
</body>
</html>
