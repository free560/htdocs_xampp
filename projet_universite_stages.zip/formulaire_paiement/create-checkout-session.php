<?php
// Nécessite le SDK Stripe PHP : composer require stripe/stripe-php
require __DIR__ . '/vendor/autoload.php';

header('Content-Type: application/json; charset=utf-8');

// Clé secrète Stripe (à mettre dans une variable d'environnement en production, jamais en dur dans le code)
\Stripe\Stripe::setApiKey('sk_test_VOTRE_CLE_SECRETE_STRIPE');

$body = json_decode(file_get_contents('php://input'), true);

$nom     = $body['nom_complet'] ?? '';
$email   = $body['email'] ?? '';
$pays    = $body['pays'] ?? '';
$montant = (float)($body['montant'] ?? 0);

if (!$nom || !$email || !$pays || $montant <= 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Champs manquants ou montant invalide.']);
    exit;
}

try {
    $session = \Stripe\Checkout\Session::create([
        'payment_method_types' => ['card'],
        'customer_email' => $email,
        'line_items' => [[
            'price_data' => [
                'currency' => 'usd',
                'product_data' => [
                    'name' => 'Paiement - ' . $nom,
                ],
                // Stripe attend le montant en centimes
                'unit_amount' => (int) round($montant * 100),
            ],
            'quantity' => 1,
        ]],
        'mode' => 'payment',
        // Ces paramètres correspondent à ceux transmis par le formulaire (équivalent de ceux
        // qu'utilisait votre intégration AfriRegister : nom, email, pays, montant)
        'metadata' => [
            'nom_complet' => $nom,
            'pays' => $pays,
        ],
        'success_url' => 'http://localhost/projet/formulaire_paiement/success.php?session_id={CHECKOUT_SESSION_ID}',
        'cancel_url'  => 'http://localhost/projet/formulaire_paiement/cancel.php',
    ]);

    echo json_encode(['success' => true, 'url' => $session->url]);

} catch (\Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
