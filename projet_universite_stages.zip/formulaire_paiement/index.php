<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Paiement en ligne</title>
<link rel="stylesheet" href="../app1_universite/style.css">
</head>
<body>
<h1>Formulaire de paiement</h1>

<form id="paymentForm">
    <label>Nom complet</label>
    <input type="text" name="nom_complet" required>

    <label>Email</label>
    <input type="email" name="email" required>

    <!-- Champ pays : liste déroulante remplie dynamiquement via l'API REST Countries -->
    <label>Pays</label>
    <select name="pays" id="paysSelect" required>
        <option value="">Chargement des pays...</option>
    </select>

    <label>Montant (USD)</label>
    <input type="number" name="montant" id="montant" min="1" step="0.01" required>

    <button type="submit">Payer avec Stripe</button>
</form>

<div id="erreur" style="color:red;"></div>

<script>
// 1) Remplir la liste déroulante des pays via une API publique (aucune clé requise)
async function chargerPays() {
    const select = document.getElementById('paysSelect');
    try {
        const res = await fetch('https://restcountries.com/v3.1/all?fields=name,cca2');
        const pays = await res.json();
        pays.sort((a, b) => a.name.common.localeCompare(b.name.common));

        select.innerHTML = '<option value="">-- Sélectionner un pays --</option>';
        pays.forEach(p => {
            const opt = document.createElement('option');
            opt.value = p.cca2;              // code pays ISO (ex: BI, FR, US)
            opt.textContent = p.name.common;  // nom affiché
            select.appendChild(opt);
        });
    } catch (e) {
        select.innerHTML = '<option value="">Impossible de charger la liste des pays</option>';
        console.error(e);
    }
}
chargerPays();

// 2) Soumission du formulaire -> création d'une session de paiement Stripe côté serveur
document.getElementById('paymentForm').addEventListener('submit', async function (e) {
    e.preventDefault();
    document.getElementById('erreur').textContent = '';

    const formData = new FormData(this);
    const payload = Object.fromEntries(formData.entries());

    try {
        const res = await fetch('create-checkout-session.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        const data = await res.json();

        if (data.url) {
            window.location.href = data.url; // redirection vers la page de paiement Stripe
        } else {
            document.getElementById('erreur').textContent = data.message || 'Erreur lors de la création du paiement.';
        }
    } catch (err) {
        document.getElementById('erreur').textContent = 'Erreur réseau : ' + err.message;
    }
});
</script>
</body>
</html>
